<?php
require('conexion.php');
require('users.php');
session_start();
function filtrado($datos)
{
    $datos = trim($datos);
    $datos = stripslashes($datos);
    $datos = htmlspecialchars($datos);
    return $datos;
}
if (isset($_SESSION["username"])){
    echo "Bienvenido a tu sesión ".filtrado($_SESSION["username"]);
}
else{
    header('location: loginform.php');
}
if (isset($_POST["submit"])) {
    header('location: logout.php');
}
?>
<html>
<body>
    <form method="post" action="private.php" enctype="multipart/form-data">
        <input type="submit" name="submit" value="Cerrar sesión"><br>
    </form>
</body>

</html>