<?php
require('conexion.php');
require('users.php');
session_start();
//errores
$errores = [];
$username = "";
if (isset($_POST["submit"])) {
    $username = ($_POST["username"] ?? "");
    $email = ($_POST["email"] ?? "");
    $password = ($_POST["password"] ?? "");
    $passwordconf = ($_POST["passwordconf"] ?? "");
    if (empty($_POST["username"])) {
        $errores[] = "El usuario no puede estar vacío";
    }
    if (empty($_POST["email"])) {
        $errores[] = "El correo no puede estar vacío";
    }
    if (!filter_var($_POST["email"], FILTER_VALIDATE_EMAIL)) {
        $errores[] = "El correo no es válido";
    }
    if (empty($_POST["password"])) {
        $errores[] = "La contraseña no puede estar vacía";
    }
    if (($_POST["password"])!=($_POST["passwordconf"])){
        $errores[] = "Las contraseñas no coinciden";
    }
//comprobación si el usuario existe
    $sql = "SELECT * FROM users WHERE username = ?";
    $stm = $pdo->prepare($sql);

    $stm->bindParam(1, $username);

    $resultado = $stm->execute();
    $registro = $stm->fetch();
    if ($registro) {
        $errores[] = "Este usuario ya existe";
    }
//comprobación si el correo existe
$sql = "SELECT * FROM users WHERE email = ?";
$stm = $pdo->prepare($sql);

$stm->bindParam(1, $email);

$resultado = $stm->execute();
$registro = $stm->fetch();
if ($registro) {
    $errores[] = "Este correo ya está en uso";
}
//registro usuario
    if (!$errores) {
            $sql = "INSERT INTO users (username, email, password) VALUES (?, ?, ?)";
            $stm = $pdo->prepare($sql);
            
        $stm->bindParam(1, $username);
        $stm->bindParam(2, $email);
        $stm->bindParam(3, $password);
       
        $resultado = $stm->execute();
        if ($resultado==1) {
            $_SESSION["username"] = $username;
            header('location: private.php');
        } else {
            $errores[] = "Registro incorrecto";
        }
    }
}
?>
<!--muestra errores-->
<ul>
    <?php if (isset($errores)) {
        foreach ($errores as $error) {
            echo "<li> $error </li>";
        }
    }
    ?>
</ul>
<!--HTML-->
<html>

<body>
    <form method="post" action="registerform.php" enctype="multipart/form-data">
        Nombre de usuari@
        <input type="text" name="username" value=<?= $username ?>><br><br>
        Correo electrónico
        <input type="text" name="email"><br><br>
        Contraseña
        <input type="password" name="password"><br><br>
        Confirmar contraseña
        <input type="password" name="passwordconf"><br><br>
        <input type="submit" name="submit" value="Registrarse"><br>
        ¿Ya eres miembro? <?php echo '<a href="http://127.0.0.1:8080/loginform.php">Iniciar sesión</a>'; ?>
    </form>
</body>

</html>