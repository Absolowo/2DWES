<?php
session_start();
session_destroy();
?>
<html>
<body>
    <form method="post" action="private.php" enctype="multipart/form-data">
    Has cerrado tu sesión, puedes volver a iniciarla <?php echo '<a href="http://127.0.0.1:8080/loginform.php">aquí</a>'; ?>
    </form>
</body>

</html>