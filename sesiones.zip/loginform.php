<?php
require('conexion.php');
require('users.php');
session_start();
//errores
$errores = [];
$username = "";
if (isset($_POST["submit"])) {
    $username = ($_POST["username"] ?? "");
    $password = ($_POST["password"] ?? "");
    if (empty($_POST["username"])) {
        $errores[] = "El usuario no puede estar vacío";
    }
    if (empty($_POST["password"])) {
        $errores[] = "La contraseña no puede estar vacía";
    }
//login
    if (!$errores) {
        $sql = "SELECT * FROM users WHERE username = ? AND password = ?";
        $stm = $pdo->prepare($sql);

        $stm->bindParam(1, $username);
        $stm->bindParam(2, $password);

        $resultado = $stm->execute();
        $registro = $stm->fetch();
        if ($registro) {
            $_SESSION["username"] = $username;
            header('location: private.php');
        } else {
            $errores[] = "Login incorrecto";
        }
    }
}
?>
<!--muestra errores-->
<ul>
    <?php if (isset($errores)) {
        foreach ($errores as $error) {
            echo "<li> $error </li>";
        }
    }
    ?>
</ul>
<!--HTML-->
<html>

<body>
    <form method="post" action="loginform.php" enctype="multipart/form-data">
        Nombre de usuari@
        <input type="text" name="username"value=<?= $username ?>><br><br>
        Contraseña
        <input type="password" name="password"><br><br>
        <input type="submit" name="submit" value="Acceder"><br>
        ¿Todavia no eres miembro? <?php echo '<a href="http://127.0.0.1:8080/registerform.php">Registrate</a>'; ?>
    </form>
</body>

</html>